from pathlib import Path
import json, re, zipfile, hashlib, openpyxl, shutil

ROOT = Path(__file__).resolve().parents[1]
DATA_XLSX = Path('/mnt/data/E資格_学習履歴管理シート_MVP.xlsx')

def main():
    assert (ROOT/'Code.gs').exists()
    assert (ROOT/'ImageManifest.gs').exists()
    assert (ROOT/'ImageSupport.gs').exists()
    assert (ROOT/'Index.html').exists()
    assert (ROOT/'Client.html').exists()

    code=(ROOT/'Code.gs').read_text(encoding='utf-8')
    m=re.search(r'function publicQuestion_\(q, node, mode\) \{([\s\S]*?)\n\}', code)
    assert m, 'publicQuestion_ not found'
    assert 'correct_option' not in m.group(1), 'correct_option leaked by publicQuestion_'

    manifest_text=(ROOT/'ImageManifest.gs').read_text(encoding='utf-8')
    j=re.search(r'Object\.freeze\((\{.*\})\);', manifest_text, re.S)
    assert j, 'manifest JSON not found'
    manifest=json.loads(j.group(1))
    assert len(manifest)==148
    assert manifest['EXAM-A4-Q039']['q']==[0,1]
    assert manifest['EXAM-A4-Q039']['s']=='9c6d67191a37caa0'

    client=(ROOT/'Client.html').read_text(encoding='utf-8')
    assert 'preloadBundle(bundle)' in client
    assert 'renderQuestion(q, bundle, seq)' in client
    assert client.index('preloadBundle(bundle)') < client.index('renderQuestion(q, bundle, seq)', client.index('preloadBundle(bundle)'))
    assert 'rejectRenderedImage' in client

    print('package_tests=PASS')
    print('manifest_entries=148')
    print('a4_q039=PASS')
    print('correct_answer_preload_leak=PASS')
    print('image_preload_before_render=PASS')

if __name__ == '__main__':
    main()
